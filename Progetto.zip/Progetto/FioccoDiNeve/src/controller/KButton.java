package controller;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/**
 * Crea un bottone, il Kush Button (KButton).
 *
 * @version 04/10/2019
 * @author Kushtrim Rushi
 */
public class KButton implements MouseListener, MouseMotionListener {

    /**
     * Definisce il bordo del bottone.
     */
    public static final int BORDER = 3;

    /**
     * Coordinata X bottone.
     */
    private int xButton;

    /**
     * Coordinata Y bottone.
     */
    private int yButton;

    /**
     * Larghezza bottone.
     */
    private int width;

    /**
     * Altezza bottone.
     */
    private int height;

    /**
     * Colore del bottone.
     */
    private Color colore = new Color(35, 35, 35);

    /**
     * Colore della scritta all'interno del bottone.
     */
    private Color coloreTesto = new Color(26, 232, 128);

    /**
     * Testo all'intreno del bottone.
     */
    private String testo;

    /**
     * Controllo del click del bottone.
     */
    private boolean click = false;

    /**
     * Riferimento all'interfaccia.
     */
    private InterfacciaIniziale ii;

    /**
     * Riferimento a triangolo.
     */
    private Triangolo t;

    private boolean over = false;

    /**
     * Costruttore base.
     *
     * @param x Posizione X del bottone.
     * @param y Posizione Y del bottone.
     * @param width Larghezza del bottone.
     * @param height Altezza del bottone.
     * @param testo Testo del bottone.
     */
    public KButton(int x, int y, int width, int height, String testo) {
        this.xButton = x;
        this.yButton = y;
        this.width = width;
        this.height = height;
        this.testo = testo;
    }

    /**
     * Richiama il costruttore con il testo ma definisce anche il colore.
     *
     * @param x Posizione X del bottone.
     * @param y Posizione Y del bottone.
     * @param width Larghezza del bottone.
     * @param height Altezza del bottone.
     * @param testo Testo del bottone.
     * @param ii Riferimento all'interfaccia.
     */
    public KButton(int x, int y, int width, int height, String testo, InterfacciaIniziale ii) {
        this(x, y, width, height, testo);
        this.ii = ii;
    }

    public KButton(int x, int y, int width, int height, String testo, Triangolo t) {
        this(x, y, width, height, testo);
        this.t = t;
    }

    /**
     * Genera il fiocco di neve.
     *
     * @param e Evento click.
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) {
            if (e.getX() >= this.xButton && e.getX() <= this.xButton + this.width
                    && e.getY() >= this.yButton
                    && e.getY() <= this.yButton + this.height) {
                this.click = true;

                if (this.ii != null) {
                    this.ii.repaint();
                }
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    /**
     * Disegna il bottone.
     *
     * @param g Contesto grafico.
     */
    public void paint(Graphics g) {
        //Bordo del button.
        if (!this.over) {
            g.setColor(this.coloreTesto);
            g.fillRect(this.xButton, this.yButton, this.width, this.height);

            g.setColor(this.colore);
            g.fillRect(this.xButton + BORDER, this.yButton + BORDER,
                    this.width - BORDER * 2, this.height - BORDER * 2);
        } else {
            g.setColor(this.coloreTesto);
            g.fillRect(this.xButton - 5, this.yButton - 5, this.width + 10, this.height + 10);

            g.setColor(this.colore);
            g.fillRect(this.xButton + BORDER - 5, this.yButton + BORDER - 5,
                    this.width - BORDER * 2 + 10, this.height - BORDER * 2 + 10);

        }

        g.setColor(this.coloreTesto);
        g.drawString(this.testo, this.xButton + (this.width / 4), this.yButton + (this.height / 2) + 5);
    }

    /**
     * Getter del click del bottone.
     *
     * @return Ritorna true se il bottone e' stato cliccato altrimenti torna
     * false.
     */
    public boolean isClicked() {
        return this.click;
    }

    /**
     * Set il click del bottone a false.
     */
    public void setClicked() {
        this.click = false;
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }

    /**
     * Quando si passa sopra con il mouse cambia il colore delle scritte.
     *
     * @param e
     */
    @Override
    public void mouseMoved(MouseEvent e) {
        if (e.getX() >= this.xButton && e.getX() <= this.xButton + this.width
                && e.getY() >= this.yButton
                && e.getY() <= this.yButton + this.height) {
            this.coloreTesto = new Color(0, 214, 255);
            this.colore = new Color(255, 255, 255);
            this.over = true;
        } else {
            this.coloreTesto = new Color(26, 232, 128);
            this.colore = new Color(35, 35, 35);
            this.over = false;
        }
        if (this.ii != null) {
            this.ii.repaint();
        }
        if (this.t != null) {
            this.t.repaint();
        }
    }
}
