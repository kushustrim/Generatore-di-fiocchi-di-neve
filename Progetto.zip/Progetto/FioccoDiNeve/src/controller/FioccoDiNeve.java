package controller;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.PathIterator;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

/**
 * La classe definisce e disegna un fiocco di neve.
 *
 * @version 11/10/2019
 * @author Kushtrim Rushi
 */
public class FioccoDiNeve extends JPanel {

    /**
     * Riferimento al triangolo, che permette di prendere i valori neccesari.
     */
    private Triangolo t;

    /**
     * Poligono del triangolo.
     */
    private Polygon triangolo;

    /**
     * Lista di poligoni.
     */
    private List<Poligono> poligoni;

    /**
     * Lista di tutte le aree, sia del triangolo sia dei poligoni.
     */
    private List<Area> aree = new ArrayList<Area>();

    /**
     * Area che alla fine verrà stampata.
     */
    private Area areaFinale;

    /**
     * Array dei poligoni.
     */
    private Shape[] poligoniFinali = new Shape[6];

    /**
     * Array dei poligoni specchiati.
     */
    private Shape[] reversePoligoni = new Shape[6];

    /**
     * Poligono finale spostato nel posto giusto e con i poligoni sottratti.
     */
    private Polygon poli;

    /**
     * Uguale a poli tranne che è specchiato.
     */
    private Polygon reversePoli;

    /**
     * Definisce un fiocco di neve.
     *
     * @param t Riferimento al traingolo.
     */
    public FioccoDiNeve(Triangolo t) {
        this.setDoubleBuffered(true);
        this.t = t;
        this.triangolo = this.t.getTriangolo();
        this.poligoni = this.t.getPoligoni();
        togliPoli();
        spostaPoligoni();
        trasformaArea();
        this.poli = toPolygon();
        this.reversePoli = reversedPolygon(this.poli);
        rotatePointMatrix(this.poli, true);
        rotatePointMatrix(this.reversePoli, false);
    }

    /**
     * Sposta tutto il poligono in sopra così che il punto in basso del poligoni
     * sia in mezzo alla pagina.
     */
    public void spostaPoligoni() {
        Punto b = this.t.getPuntoBasso();
        double diff = b.getY() - 0.5;
        if (!this.poligoni.isEmpty()) {
            for (int i = 0; i < this.poligoni.size(); i++) {
                for (int j = 0; j < this.poligoni.get(i).getSizePunto(); j++) {
                    Punto org = this.poligoni.get(i).getPunto(j);
                    Punto change = new Punto(org.getX(), org.getY() - diff);
                    this.poligoni.get(i).cambiaPunto(change, j);
                }
            }
        }
        int[] x = this.triangolo.xpoints;
        int[] y = new int[3];
        for (int i = 0; i < y.length; i++) {
            y[i] = this.triangolo.ypoints[i] - (int) (diff * (double) this.getHeight());
        }
        this.triangolo = new Polygon(x, y, 3);
    }

    /**
     * Elimina l'ultimo poligono in caso questo non sia chiuso.
     */
    public void togliPoli() {
        if (!this.poligoni.get(this.poligoni.size() - 1).isChiuso()) {
            this.poligoni.remove(this.poligoni.get(this.poligoni.size() - 1));
        }
    }

    /**
     * Trasforma i poligoni e il trinagolo in aree, fa i calcoli dovuti, per poi
     * ristrasformare in un poligono.
     */
    public void trasformaArea() {
        this.areaFinale = new Area(this.triangolo);
        if (!this.poligoni.isEmpty()) {
            for (int i = 0; i < this.poligoni.size(); i++) {
                this.areaFinale.subtract(new Area(this.poligoni.get(i).getPoligono()));
            }
        }
    }

    /**
     * Trasfotma un area in un poligono.
     *
     * @return Ritorna il poligono che è stato trasformato.
     */
    public Polygon toPolygon() {
        PathIterator iterator = this.areaFinale.getPathIterator(null);
        float[] floats = new float[6];
        Polygon polygon = new Polygon();
        while (!iterator.isDone()) {
            int type = iterator.currentSegment(floats);
            int x = (int) floats[0];
            int y = (int) floats[1];
            if (type != PathIterator.SEG_CLOSE) {
                polygon.addPoint(x, y);
                System.out.println("adding x = " + x + ", y = " + y);
            }
            iterator.next();
        }
        return polygon;
    }

    /**
     * Il metodo specchia il poligono finale.
     *
     * @param poligonoFinale Poligono finale.
     * @return Ritorna la parte specchiata del poligono finale.
     */
    public Polygon reversedPolygon(Polygon poligonoFinale) {
        int difference = 0;
        int centerX = this.getWidth() / 2;
        int[] xPos = new int[poligonoFinale.npoints];
        for (int i = 0; i < poligonoFinale.npoints; i++) {
            difference = Math.abs(poligonoFinale.xpoints[i] - centerX);
            xPos[i] = centerX + difference;
        }
        Polygon reversedPolygon = new Polygon(xPos, poligonoFinale.ypoints, poligonoFinale.npoints);
        return reversedPolygon;
    }

    /**
     * Ruota i poligoni.
     * 
     * @param polygon Poligono base che serve per ruotare.
     * @param normal Controllo che serve per capire se poligono normale o specchiato.
     */
    public void rotatePointMatrix(Polygon polygon, boolean normal) {
        double angle = 0;
        for (int i = 0; i < this.poligoniFinali.length; i++) {
            AffineTransform tx = new AffineTransform();
            tx.rotate(Math.toRadians(angle), this.getWidth() / 2, this.getHeight() / 2);
            Shape s = tx.createTransformedShape(polygon);
            if(normal){
                this.poligoniFinali[i] = s;
            }else{
                this.reversePoligoni[i] = s;
            }
            angle += 60;
        }

    }

    /**
     * Disegna un fiocco di neve.
     *
     * @param g Contesto grafico.
     */
    public void paint(Graphics g) {
        Toolkit.getDefaultToolkit().sync();

        Graphics2D g2 = (Graphics2D)g;
        
        g.setColor(Color.cyan);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        g.setColor(Color.white);
        for(int i = 0; i < this.poligoniFinali.length; i++){
            g2.fill(this.poligoniFinali[i]);
            g2.fill(this.reversePoligoni[i]);
        }
    }
}
