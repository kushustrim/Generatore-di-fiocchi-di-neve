package controller;

/**
 * Tiene i punti del poligono in double.
 *
 * @version 18/10/2019
 * @author Kushtrim Rushi
 */
public class Punto {
    
    /**
     * X del punto.
     */
    private double x;
    
    /**
     * Y del punto.
     */
    private double y;
    
    /**
     * Costruttore di un punto.
     * 
     * @param x X del punto.
     * @param y Y del punto.
     */
    public Punto (double x, double y){
        this.x = x;
        this.y = y;
    }
    
    /**
     * Getter della X del punto.
     * 
     * @return Ritorna la X del punto.
     */
    public double getX(){
        return this.x;
    }
    
    /**
     * Getter della Y del punto.
     * 
     * @return Ritorna la Y del punto.
     */
    public double getY(){
        return this.y;
    }
    
    /**
     * Set il punto, solo nel caso del drag.
     * 
     * @param p Nuovo punto.
     */
    public void setPoint(Punto p){
        this.x = p.getX();
        this.y = p.getY();
    }
    
    /**
     * Scrive il punto, serve essenzialmente per il salvataggio dei punti.
     * 
     * @return La strainga scritta nel formato giusto.
     */
    public String scriviPunto(){
        String scrivi = this.x + "," + this.y + "\n";
        return scrivi;
    }
}
