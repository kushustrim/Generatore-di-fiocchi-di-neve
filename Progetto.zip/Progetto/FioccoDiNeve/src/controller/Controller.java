package controller;

import java.awt.Dimension;
import java.nio.file.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;

/**
 * Controller del triangolo che al click del genera carica il fiocco di neve.
 *
 * @version 11/10/2019
 * @author Kushtrim Rushi
 */
public class Controller extends JFrame {

    /**
     * URL dei punti salvati.
     */
    public static final Path URL = Paths.get("punti.txt");

    /**
     * Intefaccia iniziale.
     */
    private InterfacciaIniziale ii;

    /**
     * Controlla il bottone nuovo fiocco.
     */
    private boolean newClicked = false;

    /**
     * Controlla il bottone carica fiocco.
     */
    private boolean caricaClicked = false;

    /**
     * Lista dei punti salvati.
     */
    private List<String> lines = new ArrayList<String>();

    /**
     * Triangolo.
     */
    private Triangolo triangolo;

    /**
     * Controlla che il bottone sia stato cliccato (bottone genera).
     */
    private boolean generaClicked = false;

    /**
     * Fiocco di neve.
     */
    private FioccoDiNeve fdn;

    /**
     * Dimensione della finestra.
     */
    private Dimension d = new Dimension(1024, 768);
    
    /**
     * Controllo che esiste il fiocco di neve.
     */
    private boolean esiste = false;

    /**
     * Costruttore del panel che viene inserito in un JFrame.
     */
    public Controller() {

        this.setTitle("Interfaccia");

        this.setSize(d);
        this.setMinimumSize(d);
        this.setResizable(false);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.ii = new InterfacciaIniziale(this);

        this.add(this.ii);
    }

    /**
     * Metodo pricipale.
     *
     * @param args Argomenti da linea di comando.
     */
    public static void main(String[] args) {
        Controller c = new Controller();
        c.setVisible(true);
    }

    /**
     * Controlla che il tasto nuovo fiocco sia stato cliccato.
     */
    public void checkNew() {
        if (!this.newClicked) {
            isClicked();
        }

        if (this.newClicked) {
            this.setTitle("Triangolo");

            this.remove(this.ii);

            this.triangolo = new Triangolo(this);
            this.add(this.triangolo);

            // E' un po' cheattare ma funziona quindi va bene.
            this.setSize(d.width, d.height + 1);
            this.setSize(d);

            this.setResizable(true);
        }
    }

    /**
     * Controllache il tasto carica punti sia cliccato.
     */
    public void checkCarica() {
        isClicked();
        if (this.caricaClicked) {
            if (Files.exists(URL)) {
                if (Files.notExists(URL)) {
                    this.newClicked = true;
                    this.caricaClicked = false;
                    checkNew();
                } else {
                    this.setTitle("Triangolo");

                    try {

                        this.lines = Files.readAllLines(URL);

                        this.remove(this.ii);

                        this.triangolo = new Triangolo(this, this.lines);
                        this.add(this.triangolo);

                        // E' un po' cheattare ma funziona quindi va bene.
                        this.setSize(d.width, d.height + 1);
                        this.setSize(d);

                        this.setResizable(true);
                    } catch (IOException e) {
                        System.out.println("Errore nella lettura del file");
                    }
                }
            } else {
                this.newClicked = true;
                this.caricaClicked = false;
                checkNew();
            }
        }
    }

    /**
     * Controlla che il bottone genera sia stato cliccato, in tal caso cambia il
     * componente triangolo con il fiocco di neve.
     */
    public void checkGenera() {
        isClicked();
        if (this.generaClicked) {
            this.setTitle("FioccoDiNeve");
            this.fdn = new FioccoDiNeve(this.triangolo);
            this.esiste = true;
            this.remove(this.triangolo);
            this.add(this.fdn);
            Dimension d1 = this.triangolo.getGrandezza();
            // E' un po' cheattare ma funziona quindi va bene.
            this.setSize(d1.width, d.height + 1);
            this.setSize(d1);
        }
    }

    /**
     * Controlla che il tasto genera sia cliccato.
     */
    public void isClicked() {
        if (this.newClicked || this.caricaClicked) {
            if (this.triangolo != null) {
                this.generaClicked = this.triangolo.isGeneraClicked();
            }
        }
        if (this.newClicked == false) {
            this.newClicked = this.ii.isNewClicked();
        }
        if (this.caricaClicked == false) {
            this.caricaClicked = this.ii.isCaricaClicked();
        }
    }
    
    /**
     * Controllo che il fiocco sia stato creato (nome non molto azzecato).
     * 
     * @return Ritorna se il fiocco sia stato generato true altrimenti false.
     */
    public boolean getFiocco(){
        return this.esiste;
    }
}
