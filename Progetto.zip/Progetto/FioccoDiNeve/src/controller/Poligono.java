package controller;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

/**
 * Crea e gestisce un poligono.
 *
 * @version 27/09/2019
 * @author Kushtrim Rushi
 */
public class Poligono implements MouseListener, MouseMotionListener {

    /**
     * Margine di errore per rimuovere il puntino.
     */
    public static final int ERRORE = 4;

    /**
     * Raggio puntini.
     */
    public static final int RAGGIO = ERRORE * 2;

    /**
     * Lista dei punti del poligono.
     */
    private List<Punto> punti = new ArrayList<Punto>();

    /**
     * Contralla che il poligono e' chiuso.
     */
    private boolean chiuso = false;

    /**
     * Riferimento al frame.
     */
    private Triangolo triangolo;

    /**
     * Poligono finale una volta che esso e' chiuso.
     */
    private Polygon poligonoFinale;

    /**
     * X schermo, vecchio valore.
     */
    private int xSchermo = 1024;

    /**
     * Y schermo, vecchio valore.
     */
    private int ySchermo = 768;

    /**
     * Controlla che il mouse sia all'interno del punto. Con un margine di
     * Errore di 1 px.
     *
     * @param p Punto del pallino.
     * @param m Punto del mouse.
     * @return Ritorna se all'interno (true) o se all'esterno (false).
     */
    public boolean contains(Point p, Point m) {
        return p.distance(m) <= ERRORE;
    }

    /**
     * Set la grandezza dello schermo.
     *
     * @param width Larghezza schermo.
     * @param height Altezza schermo.
     */
    public void setSizeSchermo(int width, int height) {
        this.xSchermo = width;
        this.ySchermo = height;
    }

    /**
     * Calcola il poligono finale.
     */
    public void disegnaPoligono() {
        int[] x = new int[this.punti.size()];
        int[] y = new int[this.punti.size()];
        for (int i = 0; i < this.punti.size(); i++) {
            x[i] = (int) (this.punti.get(i).getX() * this.xSchermo);
            y[i] = (int) (this.punti.get(i).getY() * this.ySchermo);
        }
        this.poligonoFinale = new Polygon(x, y, this.punti.size());
    }

    /**
     * Salva i punti.
     *
     * @return Stringa con i punti salvati.
     */
    public StringBuilder salvaPunti() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < this.punti.size(); i++) {
            s = s.append(this.punti.get(i).scriviPunto());
        }
        s = s.append("\n");
        return s;
    }

    /**
     * Aggiunge i punti in caso questi vengano caricati e non creati.
     *
     * @param x Punto X del punto.
     * @param y Punto Y del punto.
     */
    public void addPunti(double x, double y) {
        this.punti.add(new Punto(x, y));
        if (this.chiuso == false) {
            this.chiuso = true;
        }
    }
    
    /**
     * Permette di cambiare il punto da fiocco di neve.
     * 
     * @param p Punto modificato.
     * @param indice Indice del punto
     */
    public void cambiaPunto(Punto p, int indice){
        this.punti.get(indice).setPoint(p);
    }

    /**
     * Aggiunge e toglie punti alla lista. Click destro aggiunge, click sinistro
     * toglie.
     *
     * @param e Evento click.
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if (this.chiuso == false && e.getX() > 200) {
            Point mouse = e.getPoint();
            double xPunto = (double) mouse.x / (double) this.xSchermo;
            double yPunto = (double) mouse.y / (double) this.ySchermo;
            Punto punto = new Punto(xPunto, yPunto);

            // Aggiunge i punti.
            // Tasto sinistro.
            if (e.getButton() == MouseEvent.BUTTON1) {
                if (this.punti.size() < 3) {
                    this.punti.add(punto);
                } else {
                    Point primoPunto = new Point((int) (this.punti.get(0).getX() * this.xSchermo),
                            (int) (this.punti.get(0).getY() * this.ySchermo));
                    if (contains(primoPunto, mouse)) {
                        this.chiuso = true;
                    } else {
                        this.punti.add(punto);
                    }
                }
                this.triangolo.repaint();
            }

            // Toglie i punti in caso esistano.
            // Tasto destro.
            if (e.getButton() == MouseEvent.BUTTON3) {
                for (int i = 0; i < this.punti.size(); i++) {
                    Point pallino = new Point((int) (this.punti.get(i).getX() * this.xSchermo),
                            (int) (this.punti.get(i).getY() * this.ySchermo));
                    if (contains(pallino, mouse)) {
                        this.punti.remove(this.punti.get(i));
                    }
                }
            }
        }
        this.triangolo.repaint();
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    /**
     * In caso che il mouse trascino un pallino questa modifica le coordinate.
     * Controlla che effetivamente sia sopra una pallino il mouse.
     *
     * @param e Evento trascina.
     */
    @Override
    public void mouseDragged(MouseEvent e) {
        if (this.chiuso == false) {
            for (int i = 0; i < this.punti.size(); i++) {
                Point pallino = new Point((int) (this.punti.get(i).getX() * this.xSchermo),
                        (int) (this.punti.get(i).getY() * this.ySchermo));

                Point mouse = e.getPoint();
                double xPunto;
                double yPunto = (double) mouse.y / (double) this.ySchermo;

                if (mouse.x < 200) {
                    xPunto = 200.0 / (double) this.xSchermo;
                } else {
                    xPunto = (double) mouse.x / (double) this.xSchermo;
                }

                Punto punto = new Punto(xPunto, yPunto);

                if (contains(pallino, mouse)) {
                    this.punti.get(i).setPoint(punto);
                    this.triangolo.repaint();
                }
            }
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    /**
     * Costruttore del poligono.
     *
     * @param t Riferimento al triangolo.
     */
    public Poligono(Triangolo t) {
        this.triangolo = t;
    }

    /**
     * Disegna il singolo poligono.
     *
     * @param g Contesto grafico.
     */
    public void paint(Graphics g) {
        if (!this.punti.isEmpty()) {

            if (this.chiuso) {
                g.setColor(Color.orange);
                disegnaPoligono();
                g.fillPolygon(this.poligonoFinale);
            } else {

                if (this.punti.size() == 1) {

                    g.setColor(Color.red);
                    g.fillOval((int) (this.punti.get(0).getX() * this.xSchermo) - ERRORE,
                            (int) (this.punti.get(0).getY() * this.ySchermo) - ERRORE, RAGGIO, RAGGIO);
                } else {

                    for (int i = 0; i < (this.punti.size() - 1); i++) {

                        g.setColor(Color.black);
                        g.drawLine((int) (this.punti.get(i).getX() * this.xSchermo),
                                (int) (this.punti.get(i).getY() * this.ySchermo),
                                (int) (this.punti.get(i + 1).getX() * this.xSchermo),
                                (int) (this.punti.get(i + 1).getY() * this.ySchermo));

                        if (i == 0) {
                            g.setColor(Color.red);
                        } else {
                            g.setColor(Color.cyan);
                        }

                        g.fillOval((int) (this.punti.get(i).getX() * this.xSchermo) - ERRORE,
                                (int) (this.punti.get(i).getY() * this.ySchermo) - ERRORE, RAGGIO, RAGGIO);
                    }
                    int indice = this.punti.size() - 1;
                    g.setColor(Color.cyan);
                    g.fillOval((int) (this.punti.get(indice).getX() * this.xSchermo) - ERRORE,
                            (int) (this.punti.get(indice).getY() * this.ySchermo) - ERRORE, RAGGIO, RAGGIO);
                }
            }
        }
    }

    /**
     * Getter della chiusura del poligono.
     *
     * @return Se il poligono e' chiuso (true) se no (false);
     */
    public boolean isChiuso() {
        return this.chiuso;
    }

    /**
     * Setta la chiusura del poligono.
     *
     * @param polChiuso Se chiuso (true) o aperto(false).
     */
    public void setChiuso(boolean polChiuso) {
        this.chiuso = polChiuso;
    }
    
    /**
     * Getter del poligono trasformato a grandezza naturale.
     * 
     * @return Ritorna il poligono finale.
     */
    public Polygon getPoligono(){
        //int[] x = new int[this.punti.size()];
        //int[] y = new int[this.punti.size()];

        //for(int i = 0; i < this.punti.size(); i++){
        //    x[i] = (int)(this.punti.get(i).getX() * (double)width);
        //    y[i] = (int)(this.punti.get(i).getY() * (double)height);
        //}

        //Polygon poligono = new Polygon(x, y, this.punti.size());
        //return poligono;
        return this.poligonoFinale;
    }
    
    /**
     * Ritorna la grandezza della lista di punti.
     * 
     * @return Grandezza lista punti. 
     */
    public int getSizePunto(){
        return this.punti.size();
    }
    
    /**
     * Ritorna uno specifico punto.
     * 
     * @param indice Indice del punto.
     * @return Punto specificato.
     */
    public Punto getPunto(int indice){
        return this.punti.get(indice);
    }
}
