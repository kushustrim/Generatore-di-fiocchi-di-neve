package controller;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.List;
import java.awt.Polygon;
import java.awt.Toolkit;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Progetto di scuola. Dato un triangolo disegna un fiocco di neve.
 *
 * @version 04/10/2019
 * @author Kushtrim Rushi
 */
public class Triangolo extends JPanel {

    /**
     * URL di dove salvare i punti.
     */
    public static final Path URL = Paths.get("./punti.txt");

    /**
     * Dimensione x dello schermo.
     */
    private int xVSchermo = 1024;

    /**
     * Dimensione y dello schermo.
     */
    private int yVSchermo = 767;

    /**
     * Tringolo del disegno.
     */
    private Polygon triangolo;

    /**
     * Lista di poligoni.
     */
    private List<Poligono> poligoni = new ArrayList<Poligono>();

    /**
     * Indice poligono attuale.
     */
    private int poli = -1;

    /**
     * Bottone genera.
     */
    private KButton genera;

    /**
     * Bottone reset.
     */
    private KButton reset;

    /**
     * Bottone salva, salva i punti.
     */
    private KButton salva;

    /**
     * Riferimento al controller.
     */
    private Controller controller;

    /**
     * Dati carica all'avvio del programma.
     */
    private List<String> dati = new ArrayList<String>();
    
    /**
     * Punto più basso del triangolo originale.
     */
    private Punto puntoBasso;

    /**
     * Inizializazzione del JPanel.
     *
     * @param c Riferimento al controller.
     */
    public Triangolo(Controller c) {
        this.setDoubleBuffered(true);

        this.controller = c;

        this.genera = new KButton(50, 100, 100, 30, "GENERA", this);
        this.reset = new KButton(50, 200, 100, 30, "RESET", this);
        this.salva = new KButton(50, 300, 100, 30, "SALVA", this);

        this.addMouseListener(this.genera);
        this.addMouseMotionListener(this.genera);
        this.addMouseListener(this.reset);
        this.addMouseMotionListener(this.reset);
        this.addMouseListener(this.salva);
        this.addMouseMotionListener(this.salva);

        addPoligoni();
        calcolaTriangolo();
    }

    /**
     * Inizializza il JPanel e carica i punti salvati.
     *
     * @param c Riferimento al controller.
     * @param caricati Dati dei punti salvati.
     */
    public Triangolo(Controller c, List<String> caricati) {
        this(c);
        this.dati = caricati;
        carica();
    }

    /**
     * Controlla se il poligono e' stato chiuso (aggiunge un poligono alla
     * lista).
     */
    public void checkPoligono() {
        if (this.poligoni.get(this.poli).isChiuso()) {
            addPoligoni();
        }
    }

    /**
     * Il metodo calcola i punti del triangolo.
     */
    public void calcolaTriangolo() {
        int altezza;
        int larghezza;
        if (this.getWidth() == this.getHeight()) {
            altezza = this.getHeight() / 2;
            larghezza = (int) (altezza / Math.sqrt(3));
        } else if ((this.getWidth() * Math.sqrt(3)) < (this.getHeight() / Math.sqrt(3))) {
            larghezza = this.getWidth() / 2;
            altezza = (int) (larghezza * Math.sqrt(3));
        } else {
            altezza = this.getHeight() / 2;
            larghezza = (int) (altezza / Math.sqrt(3));
        }

        int spazioAltezza = (this.getHeight() - altezza) / 2;
        int spazioLarghezza = (this.getWidth() - larghezza) / 2;

        int spazioFinLar = spazioLarghezza + larghezza;
        int spazioFinAlt = spazioAltezza + altezza;

        int[] x = {spazioLarghezza, spazioFinLar, spazioFinLar};
        int[] y = {spazioAltezza, spazioAltezza, spazioFinAlt};

        this.triangolo = new Polygon(x, y, 3);
        this.puntoBasso = new Punto((double)((double)spazioFinLar / (double)this.getWidth()), (double)((double)spazioFinAlt / (double)this.getHeight()));
    }

    /**
     * Aggiunge un poligono con i vari listener (Mouse, MouseMotion).
     */
    public void addPoligoni() {
        ++this.poli;
        this.poligoni.add(new Poligono(this));
        this.addMouseListener(this.poligoni.get(this.poli));
        this.addMouseMotionListener(this.poligoni.get(this.poli));
    }

    /**
     * Controlla che il reset sia stato cliccato, se cosi' allora rimouve tutti
     * i poligoni.
     */
    public void checkReset() {
        if (this.reset.isClicked()) {
            this.poli = -1;
            this.poligoni.clear();

            addPoligoni();
            this.reset.setClicked();
            repaint();
            this.controller.repaint();
        }
    }

    /**
     * Controlla che il tasto salva sia cliccato, in tal caso toglie ogni
     * poligono aperto, poi salva i punti nel file punti.txt.
     */
    public void checkSalva() {
        if (this.salva.isClicked()) {
            if (this.poligoni.get(this.poligoni.size() - 1).isChiuso() == false) {
                this.poligoni.remove(this.poligoni.size() - 1);
                this.poli--;
            }
            if (this.poligoni != null) {
                StringBuilder file = new StringBuilder();
                for (int i = 0; i < this.poligoni.size(); i++) {
                    file = file.append(this.poligoni.get(i).salvaPunti());
                }
                String testoFinale = file.toString();
                try {
                    Files.write(URL, testoFinale.getBytes());
                } catch (IOException ex) {
                    System.out.println("Errore scrittura file");
                }
            }
            this.salva.setClicked();
            JOptionPane.showConfirmDialog(null, "Punti salvati");
            addPoligoni();

        }
    }

    /**
     * Carica i punti nei poligoni.
     */
    public void carica() {
        if (this.dati != null) {
            for (int i = 0; i < this.dati.size(); i++) {
                if (this.dati.get(i).isEmpty()) {
                    addPoligoni();
                } else {
                    double x = 0;
                    double y = 0;
                    String s = "";
                    for (int j = 0; j < this.dati.get(i).length(); j++) {
                        char carattere = this.dati.get(i).charAt(j);
                        if (carattere == ',') {
                            x = Double.parseDouble(s);
                            s = "";
                        } else {
                            s += carattere;
                        }
                    }
                    y = Double.parseDouble(s);
                    this.poligoni.get(this.poli).addPunti(x, y);
                }
            }
        }
    }

    /**
     * Zona di disegno.
     *
     * @param g Contesto grafico.
     */
    public void paint(Graphics g) {
        Toolkit.getDefaultToolkit().sync();

        this.controller.checkGenera();

        checkReset();
        if(this.controller.getFiocco() == false){
            checkPoligono();
        }
        checkSalva();

        g.setColor(Color.orange);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        if (this.getWidth() != this.xVSchermo || this.getHeight() != this.yVSchermo) {
            this.xVSchermo = this.getWidth();
            this.yVSchermo = this.getHeight();
            for (int i = 0; i < this.poligoni.size(); i++) {
                this.poligoni.get(i).setSizeSchermo(this.xVSchermo, this.yVSchermo);
            }
            calcolaTriangolo();
        }

        g.setColor(Color.white);
        g.fillPolygon(this.triangolo);

        for (int i = 0; i < this.poligoni.size(); i++) {
            this.poligoni.get(i).paint(g);
        }

        g.setColor(Color.black);
        g.fillRect(199, 0, 3, this.getHeight());

        this.genera.paint(g);
        this.reset.paint(g);
        this.salva.paint(g);
    }

    /**
     * Getter del click del bottone genera.
     *
     * @return Ritorna se bisogna generare il fiocco.
     */
    public boolean isGeneraClicked() {
        return this.genera.isClicked();
    }
    
    /**
     * Getter del triangolo.
     * 
     * @return Ritorna il poligono del triangolo.
     */
    public Polygon getTriangolo(){
        return this.triangolo;
    }
    
    /**
     * Getter dei poligoni.
     * 
     * @return Ritorna la lista dove sono salvati i poligoni.
     */
    public List<Poligono> getPoligoni(){
        return this.poligoni;
    }
    
    /**
     * Metodo che ritorna il punto più basso del triangolo originale.
     * 
     * @return Punto più basso del triangolo.
     */
    public Punto getPuntoBasso(){
        return this.puntoBasso;
    }
    
    /**
     * Metodo che ritorna la grandezza della finestra.
     * 
     * @return Grandezza della finestra.
     */
    public Dimension getGrandezza(){
        Dimension d = new Dimension(this.xVSchermo, this.yVSchermo);
        return d;
    }
}
