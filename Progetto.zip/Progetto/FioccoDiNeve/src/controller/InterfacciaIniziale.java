package controller;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Toolkit;
import javax.swing.JPanel;

/**
 * Initerfaccia inizale del progetto dove si permette di fare un nuovo fiocco o
 * caricarne uno vecchio.
 *
 * @version 12/10/2019
 * @author Kushtrim Rushi
 */
public class InterfacciaIniziale extends JPanel{

    /**
     * Bottone che permette di creare un nuovo fiocco.
     */
    private KButton nuovo;
    
    /**
     * Bottone che permette di caricare vecchi punti.
     */
    private KButton carica;
    
    /**
     * Riferiento al controller.
     */
    private Controller controller;
    
    /**
     * Inizializza i bottoni e l'interfaccia.
     * 
     * @param c Riferimento al controller.
     */
    public InterfacciaIniziale(Controller c){  
        this.setDoubleBuffered(true);
        
        this.controller = c;
        
        this.nuovo = new KButton(1024 / 2 - 50, 250, 100, 50, "NUOVO", this);
        this.carica = new KButton(1024 / 2 - 50, 400, 100, 50, "CARICA", this);
        
        this.addMouseListener(this.nuovo);
        this.addMouseMotionListener(this.nuovo);
        this.addMouseListener(this.carica);
        this.addMouseMotionListener(this.carica);
    }
    
    /**
     * Zona di disegno.
     * 
     * @param g Contesto grafico.
     */
    public void paint(Graphics g){
        Toolkit.getDefaultToolkit().sync();
        
        g.setColor(Color.orange);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        
        this.controller.checkNew();
        this.controller.checkCarica();
        
        this.nuovo.paint(g);
        this.carica.paint(g);
    }
    
    /**
     * Getter del tasto nuovo.
     * 
     * @return Se cliccato true altrimenti false.
     */
    public boolean isNewClicked(){
        return this.nuovo.isClicked();
    }
    
    /**
     * Getter del tasto carica.
     * 
     * @return Se cliccato true altrimenti false.
     */
    public boolean isCaricaClicked(){
        return this.carica.isClicked();
    }
}
